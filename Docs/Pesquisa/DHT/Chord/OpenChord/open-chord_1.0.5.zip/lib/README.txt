Directory for third party libs. 
If you want to use log4j (http://logging.apache.org/) or compile openchord 
place a jar named log4j.jar here. 