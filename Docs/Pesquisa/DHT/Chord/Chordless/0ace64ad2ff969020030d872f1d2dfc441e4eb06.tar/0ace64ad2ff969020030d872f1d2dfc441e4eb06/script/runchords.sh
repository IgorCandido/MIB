#!/bin/sh

java -jar build/chordless.jar jdbcurl=jdbc:hsqldb:mem:dhash2.db "$@" &
sleep 2
java -jar build/chordless.jar jdbcurl=jdbc:hsqldb:mem:dhash2.db "$@" &
java -jar build/chordless.jar jdbcurl=jdbc:hsqldb:mem:dhash3.db "$@" &
java -jar build/chordless.jar jdbcurl=jdbc:hsqldb:mem:dhash4.db "$@" 
